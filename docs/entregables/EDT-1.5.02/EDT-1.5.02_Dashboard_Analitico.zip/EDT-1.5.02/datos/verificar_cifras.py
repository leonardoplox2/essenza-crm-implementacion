"""Criterio de aceptación EDT-1.5.02: «las cifras coinciden con la base de datos».
Recalcula cada cifra del dashboard directamente desde los Excel (pandas, sin SQL) y la compara
con lo que muestra el dashboard (dashboard_data.json, calculado con SQL sobre crm_essenza.db).
Uso: python verificar_cifras.py registro.xlsx dataset.xlsx out/
"""
import sys, json, sqlite3, datetime as dt
from pathlib import Path
import pandas as pd

reg_x, ds_x, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
D = json.load(open(out / 'dashboard_data.json'))
CORTE = pd.Timestamp(D['corte'])
reg = pd.read_excel(reg_x); reg = reg[reg['ID_Cliente'] != 'CLI-TEST-001']
reg['Fecha'] = pd.to_datetime(reg['Fecha'])
ds = pd.read_excel(ds_x)
pred = pd.read_sql('SELECT * FROM predicciones', sqlite3.connect(out / 'crm_essenza.db'))  # salida del modelo
r30 = reg[(reg.Fecha >= CORTE - pd.Timedelta(days=29)) & (reg.Fecha <= CORTE)]
rec = (CORTE - reg[reg.Fecha <= CORTE].groupby('ID_Cliente').Fecha.max()).dt.days
est = pd.cut(rec, [-1, 89, 120, 10 ** 6], labels=['Normal', 'Prealerta', 'Umbral superado']).value_counts()

checks = [
    ('Clientes totales', D['kpi']['clientes'], ds['ID Cliente'].nunique()),
    ('Clientes en riesgo (medio + alto)', D['kpi']['en_riesgo'], int((pred.probabilidad >= .30).sum())),
    ('Clientes en riesgo alto', D['kpi']['riesgo_alto'], int((pred.probabilidad >= .60).sum())),
    ('Probabilidad media de abandono', D['kpi']['prob_media'], round(pred.probabilidad.mean(), 4)),
    ('Clientes con umbral superado (> 120 días)', D['kpi']['umbral_superado'], int((ds['Recency'] > 120).sum())),
    ('Clientes en prealerta (90 a 120 días)', D['kpi']['prealerta'], int(ds['Recency'].between(90, 120).sum())),
    ('Atenciones registradas', D['kpi']['atenciones'], int((reg.Fecha <= CORTE).sum())),
    ('Atenciones últimos 30 días', D['kpi']['atenciones_30d'], len(r30)),
    ('Ingresos últimos 30 días (S/)', D['kpi']['ingresos_30d'], round(float((r30['Monto Pagado'] + r30['Monto Productos']).sum()), 2)),
    ('Clientes atendidos últimos 30 días', D['kpi']['activos_30d'], r30['ID_Cliente'].nunique()),
    ('Ticket promedio por atención (S/)', D['kpi']['ticket_promedio'], round(float(reg[reg.Fecha <= CORTE]['Monto Pagado'].mean()), 2)),
    ('Calificación promedio', D['kpi']['calificacion'], round(float(reg[reg.Fecha <= CORTE]['Calificación'].mean()), 2)),
    ('Riesgo bajo', D['riesgo']['Bajo'], int((pred.probabilidad < .30).sum())),
    ('Riesgo medio', D['riesgo']['Medio'], int(pred.probabilidad.between(.30, .60, inclusive='left').sum())),
    ('Riesgo alto', D['riesgo']['Alto'], int((pred.probabilidad >= .60).sum())),
    ('Estado Normal', D['temporal']['Normal'], int(est['Normal'])),
    ('Estado Prealerta', D['temporal']['Prealerta'], int(est['Prealerta'])),
    ('Estado Umbral superado', D['temporal']['Umbral superado'], int(est['Umbral superado'])),
    ('Atenciones de junio 2026 (gráfico de evolución)', D['evolucion'][-1]['atenciones'], int((reg.Fecha.dt.strftime('%Y-%m') == '2026-06').sum())),
    ('Gasto del cliente n.° 1 del ranking (S/)', D['top'][0]['gasto'],
     round(float(reg[reg.ID_Cliente == D['top'][0]['id']][['Monto Pagado', 'Monto Productos']].sum().sum()), 2)),
]
res = [dict(cifra=c, dashboard=a, recalculo=b, coincide=bool(abs(float(a) - float(b)) < 1e-6)) for c, a, b in checks]
json.dump(res, open(out / 'verificacion.json', 'w'), ensure_ascii=False, indent=1)
for r in res: print(('OK ' if r['coincide'] else 'XX ') + r['cifra'], r['dashboard'], r['recalculo'])
print('Coinciden', sum(r['coincide'] for r in res), 'de', len(res))
