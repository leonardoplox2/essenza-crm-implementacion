"""EDT-1.5.02 · Carga la base de datos del CRM (SQLite) y calcula los datos del dashboard con SQL.

Uso: python build_db.py spa_registro_operacional.xlsx spa_dataset_modelo_predictivo.xlsx modelo_dir salida_dir
"""
import sys, json, pickle, sqlite3, datetime as dt
from pathlib import Path
import numpy as np, pandas as pd

reg_x, ds_x, mdir, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
out.mkdir(parents=True, exist_ok=True)
CORTE = '2026-06-30'                     # FECHA_CORTE_DEMO del CRM
UB, UA = 0.30, 0.60                      # umbrales de riesgo (config.py)
PRE, CRIT = 90, 120                      # umbrales temporales (config.py)

# ---------- 1. carga a la base de datos (lo que hace la sincronización del CRM)
reg = pd.read_excel(reg_x)
reg = reg[reg['ID_Cliente'] != 'CLI-TEST-001']          # registro de prueba: se excluye
db = out / 'crm_essenza.db'
if db.exists(): db.unlink()
con = sqlite3.connect(db)
reg.assign(Fecha=pd.to_datetime(reg['Fecha']).dt.strftime('%Y-%m-%d'))[
    ['ID_Atención', 'Fecha', 'ID_Cliente', 'Nombre Cliente', 'Distrito', 'Servicio', 'Categoría Servicio', 'Monto Pagado',
     'Monto Productos', 'Canceló Antes', 'Calificación']].rename(columns={
    'ID_Atención': 'id_atencion', 'Fecha': 'fecha', 'ID_Cliente': 'id_cliente', 'Nombre Cliente': 'nombre', 'Distrito': 'distrito',
    'Servicio': 'servicio', 'Categoría Servicio': 'categoria', 'Monto Pagado': 'monto_pagado', 'Monto Productos': 'monto_productos',
    'Canceló Antes': 'cancelo', 'Calificación': 'calificacion'}).to_sql('atenciones', con, index=False)

# ---------- 2. predicciones del modelo v1.0 (EDT-1.3.05)
src = open(mdir / 'evaluar_modelo.py', encoding='utf-8').read()
ns = {'np': np, 'pd': pd}
exec(src[src.index('NUM = {'):src.index('Xb = base(raw)')], ns)
raw = pd.read_excel(ds_x)
model = pickle.load(open(mdir / 'modelo' / 'modelo_abandono_v1.0.pkl', 'rb'))
REF = pickle.load(open(mdir / 'modelo' / 'referencias_variables.pkl', 'rb'))
X = ns['derive'](ns['base'](raw), REF)
p = model.predict_proba(X)[:, 1]
pred = pd.DataFrame({'id_cliente': raw['ID Cliente'], 'probabilidad': p.round(4), 'recency_dias': raw['Recency'].astype(int)})
pred['nivel_riesgo'] = np.where(pred.probabilidad >= UA, 'Alto', np.where(pred.probabilidad >= UB, 'Medio', 'Bajo'))
pred['estado_temporal'] = np.where(pred.recency_dias > CRIT, 'Umbral superado', np.where(pred.recency_dias >= PRE, 'Prealerta', 'Normal'))
pred['fecha_corte'] = CORTE; pred['version_modelo'] = '1.0'
pred.to_sql('predicciones', con, index=False)
con.commit()

# ---------- 3. consultas del dashboard (SQL sobre la base de datos)
q = lambda s, *a: con.execute(s, a).fetchall()
one = lambda s, *a: q(s, *a)[0][0]
d0 = (dt.date.fromisoformat(CORTE) - dt.timedelta(days=29)).isoformat()
kpi = dict(
    clientes=one('SELECT COUNT(*) FROM predicciones'),
    en_riesgo=one("SELECT COUNT(*) FROM predicciones WHERE nivel_riesgo IN ('Medio','Alto')"),
    riesgo_alto=one("SELECT COUNT(*) FROM predicciones WHERE nivel_riesgo='Alto'"),
    prob_media=round(one('SELECT AVG(probabilidad) FROM predicciones'), 4),
    umbral_superado=one("SELECT COUNT(*) FROM predicciones WHERE estado_temporal='Umbral superado'"),
    prealerta=one("SELECT COUNT(*) FROM predicciones WHERE estado_temporal='Prealerta'"),
    atenciones=one('SELECT COUNT(*) FROM atenciones WHERE fecha<=?', CORTE),
    atenciones_30d=one('SELECT COUNT(*) FROM atenciones WHERE fecha BETWEEN ? AND ?', d0, CORTE),
    ingresos_30d=round(one('SELECT SUM(monto_pagado+monto_productos) FROM atenciones WHERE fecha BETWEEN ? AND ?', d0, CORTE), 2),
    activos_30d=one('SELECT COUNT(DISTINCT id_cliente) FROM atenciones WHERE fecha BETWEEN ? AND ?', d0, CORTE),
    ticket_promedio=round(one('SELECT AVG(monto_pagado) FROM atenciones WHERE fecha<=?', CORTE), 2),
    calificacion=round(one('SELECT AVG(calificacion) FROM atenciones WHERE fecha<=?', CORTE), 2),
)
riesgo = {n: c for n, c in q('SELECT nivel_riesgo, COUNT(*) FROM predicciones GROUP BY nivel_riesgo')}
temporal = {n: c for n, c in q('SELECT estado_temporal, COUNT(*) FROM predicciones GROUP BY estado_temporal')}
cruce = {f'{a}|{b}': c for a, b, c in q('SELECT nivel_riesgo, estado_temporal, COUNT(*) FROM predicciones GROUP BY 1,2')}
top = [dict(id=i, nombre=n, prob=pr, nivel=nv, estado=e, dias=r, visitas=v, gasto=round(g, 2), ultima=u) for i, n, pr, nv, e, r, v, g, u in q('''
    SELECT p.id_cliente, MAX(a.nombre), p.probabilidad, p.nivel_riesgo, p.estado_temporal, p.recency_dias,
           COUNT(a.id_atencion), SUM(a.monto_pagado+a.monto_productos), MAX(a.fecha)
    FROM predicciones p JOIN atenciones a ON a.id_cliente=p.id_cliente
    GROUP BY p.id_cliente ORDER BY p.probabilidad DESC LIMIT 10''')]
cats = {c: n for c, n in q("""SELECT a.categoria, COUNT(DISTINCT p.id_cliente) FROM predicciones p
       JOIN atenciones a ON a.id_cliente=p.id_cliente WHERE p.nivel_riesgo='Alto' GROUP BY 1 ORDER BY 2 DESC""")}

# ---------- 4. evolución mensual: estado temporal en cada cierre de mes (como una sincronización mensual)
ORD = {'Normal': 0, 'Prealerta': 1, 'Umbral superado': 2}
months = pd.date_range('2024-01-31', CORTE, freq='ME').strftime('%Y-%m-%d').tolist()
if months[-1] != CORTE: months.append(CORTE)
prev, evol = {}, []
for m in months:
    rows = q('SELECT id_cliente, MAX(fecha) FROM atenciones WHERE fecha<=? GROUP BY id_cliente', m)
    cur = {}
    for cid, last in rows:
        days = (dt.date.fromisoformat(m) - dt.date.fromisoformat(last)).days
        cur[cid] = 'Umbral superado' if days > CRIT else ('Prealerta' if days >= PRE else 'Normal')
    nuevas = sum(1 for c, e in cur.items() if c in prev and ORD[e] > ORD[prev[c]])
    nuevas_pre = sum(1 for c, e in cur.items() if c in prev and e == 'Prealerta' and ORD[e] > ORD[prev[c]])
    nuevas_umb = sum(1 for c, e in cur.items() if c in prev and e == 'Umbral superado' and ORD[e] > ORD[prev[c]])
    vis = one('SELECT COUNT(*) FROM atenciones WHERE substr(fecha,1,7)=?', m[:7])
    evol.append(dict(mes=m[:7], clientes=len(cur), normal=sum(e == 'Normal' for e in cur.values()),
                     prealerta=sum(e == 'Prealerta' for e in cur.values()), umbral=sum(e == 'Umbral superado' for e in cur.values()),
                     alertas_nuevas=nuevas, nuevas_prealerta=nuevas_pre, nuevas_umbral=nuevas_umb, atenciones=vis))
    prev = cur

data = dict(corte=CORTE, version_modelo='1.0', generado=dt.datetime.now().strftime('%Y-%m-%d %H:%M'), kpi=kpi, riesgo=riesgo,
            temporal=temporal, cruce=cruce, top=top, categorias_alto=cats, evolucion=evol,
            umbrales=dict(riesgo_bajo=UB, riesgo_alto=UA, prealerta=PRE, umbral=CRIT))
json.dump(data, open(out / 'dashboard_data.json', 'w'), ensure_ascii=False, indent=1)
con.close()
print(json.dumps(dict(kpi=kpi, riesgo=riesgo, temporal=temporal, last=evol[-3:]), ensure_ascii=False, indent=1))
