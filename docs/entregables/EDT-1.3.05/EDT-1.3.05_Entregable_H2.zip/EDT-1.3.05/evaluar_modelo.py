"""EDT-1.3.05 · Evaluación, interpretabilidad y empaquetado del modelo de abandono (Essenza SPA).

Uso: python evaluar_modelo.py spa_dataset_modelo_predictivo.xlsx salida/
Reproduce el entrenamiento (EDT-1.3.04) con semilla fija y evalúa en la partición de prueba.
"""
import sys, json, hashlib, datetime as dt, pickle
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, RandomizedSearchCV, StratifiedKFold, cross_val_predict
from sklearn.metrics import (fbeta_score, roc_auc_score, recall_score, precision_score, f1_score, accuracy_score,
                             confusion_matrix, roc_curve)
from xgboost import XGBClassifier
import shap, xgboost, sklearn

SEED = 42
UMBRAL_BAJO, UMBRAL_ALTO = 0.30, 0.60
META_AUC, META_RECALL = 0.80, 0.60
src, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)

raw = pd.read_excel(src)
y = (raw['Churn'] == 'Sí').astype(int)

NUM = {'Edad': 'edad', 'Antigüedad Cliente (días)': 'antiguedad_dias', 'Total Visitas': 'total_visitas',
       'Visitas últimos 30 días': 'visitas_30d', 'Visitas últimos 90 días': 'visitas_90d',
       'Tiempo promedio entre visitas (días)': 'dias_entre_visitas', 'Frecuencia mensual': 'frecuencia_mensual',
       'Gasto Total': 'gasto_total', 'Ticket Promedio': 'ticket_promedio', 'Variabilidad del gasto': 'variabilidad_gasto',
       'Gasto Productos': 'gasto_productos', 'Compra Productos (%)': 'pct_compra_productos',
       'Cantidad Servicios Diferentes': 'servicios_diferentes', 'Descuento Promedio (%)': 'descuento_promedio',
       '% Visitas con Descuento': 'pct_visitas_descuento', 'Reserva Online (%)': 'pct_reserva_online',
       'Cancelaciones': 'cancelaciones', 'Reprogramaciones': 'reprogramaciones',
       'Calificación Promedio': 'calificacion_promedio', 'Recency': 'recency_dias'}
CAT = {'Sexo': 'sexo', 'Distrito': 'distrito', 'Categoría Favorita': 'categoria_favorita',
       'Último Método Pago': 'ultimo_metodo_pago', 'Último Canal Reserva': 'ultimo_canal_reserva'}


def base(df):
    X = df[list(NUM)].rename(columns=NUM).astype(float)
    for c, n in CAT.items():
        X[n] = df[c].astype('category')
    X['cliente_premium'] = (df['Cliente Premium'] == 'Sí').astype(int)
    return X


def fit_ref(X):
    """Parámetros de las variables derivadas, calculados SOLO con entrenamiento."""
    return dict(rec=np.sort(X['recency_dias'].values), fre=np.sort(X['total_visitas'].values),
                mon=np.sort(X['gasto_total'].values), p25_frec=float(X['frecuencia_mensual'].quantile(.25)),
                ter=X['gasto_total'].quantile([1 / 3, 2 / 3]).tolist())


def derive(X, R):
    X = X.copy()
    pct = lambda v, ref: np.searchsorted(ref, v, side='right') / len(ref)
    r = 1 - pct(X['recency_dias'], R['rec']); f = pct(X['total_visitas'], R['fre']); m = pct(X['gasto_total'], R['mon'])
    X['rfm_score'] = 0.40 * r + 0.35 * f + 0.25 * m
    X['rfm_segmento'] = np.clip(np.ceil(X['rfm_score'] * 4), 1, 4).astype(int)
    tv = X['total_visitas'].replace(0, np.nan)
    X['ratio_cancelaciones'] = (X['cancelaciones'] / tv).fillna(0)
    X['ratio_reprogramaciones'] = (X['reprogramaciones'] / tv).fillna(0)
    X['ratio_gasto_productos'] = (X['gasto_productos'] / X['gasto_total'].replace(0, np.nan)).fillna(0)
    X['ratio_visitas_recientes'] = (X['visitas_90d'] / tv).fillna(0)
    X['es_recency_critico'] = (X['recency_dias'] > 120).astype(int)
    X['sin_visitas_recientes'] = (X['visitas_90d'] == 0).astype(int)
    X['baja_frecuencia'] = (X['frecuencia_mensual'] < R['p25_frec']).astype(int)
    X['nivel_gasto'] = 1 + (X['gasto_total'] > R['ter'][0]).astype(int) + (X['gasto_total'] > R['ter'][1]).astype(int)
    return X


Xb = base(raw)
idx_tr, idx_te = train_test_split(np.arange(len(raw)), test_size=0.20, stratify=y, random_state=SEED)
REF = fit_ref(Xb.iloc[idx_tr])
X = derive(Xb, REF)
Xtr, Xte, ytr, yte = X.iloc[idx_tr], X.iloc[idx_te], y.iloc[idx_tr], y.iloc[idx_te]
spw = float((ytr == 0).sum() / (ytr == 1).sum())

common = dict(objective='binary:logistic', eval_metric='auc', enable_categorical=True, tree_method='hist',
              random_state=SEED, n_jobs=4)
baseline = XGBClassifier(scale_pos_weight=spw, **common).fit(Xtr, ytr)
grid = {'n_estimators': [100, 200, 300, 400, 500], 'max_depth': [2, 3, 4, 5, 6], 'learning_rate': [0.01, 0.03, 0.05, 0.1, 0.2],
        'subsample': [0.6, 0.7, 0.8, 0.9, 1.0], 'colsample_bytree': [0.5, 0.6, 0.7, 0.8, 1.0], 'min_child_weight': [1, 3, 5, 7],
        'gamma': [0, 0.1, 0.3, 0.5, 1.0], 'reg_lambda': [0.5, 1, 2, 5], 'scale_pos_weight': [1.0, spw]}
cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
rs = RandomizedSearchCV(XGBClassifier(**common), grid, n_iter=60, scoring='roc_auc', cv=cv, random_state=SEED, n_jobs=1)
rs.fit(Xtr, ytr)
model = rs.best_estimator_

# Umbral de decisión: el que el CRM ya tiene configurado (config.py): desde 0,30 el cliente es riesgo medio y genera alerta.
# Se confirma con predicciones fuera de pliegue del entrenamiento (sin usar la prueba).
UMBRAL_CLASE = UMBRAL_BAJO
oof = cross_val_predict(XGBClassifier(**common, **rs.best_params_), Xtr, ytr, cv=cv, method='predict_proba')[:, 1]
oof_recall = recall_score(ytr, (oof >= UMBRAL_CLASE).astype(int)); oof_prec = precision_score(ytr, (oof >= UMBRAL_CLASE).astype(int))
oof_auc = roc_auc_score(ytr, oof)
print('umbral', UMBRAL_CLASE, 'oof recall', oof_recall, 'oof prec', oof_prec, 'oof auc', oof_auc)


def metrics(m):
    p = m.predict_proba(Xte)[:, 1]; yh = (p >= UMBRAL_CLASE).astype(int)
    return p, dict(roc_auc=roc_auc_score(yte, p), recall=recall_score(yte, yh), precision=precision_score(yte, yh),
                   f1=f1_score(yte, yh), accuracy=accuracy_score(yte, yh))


p_te, M = metrics(model)
_, MB = metrics(baseline)
_, M50 = (lambda p: (p, dict(recall=recall_score(yte, (p >= .5).astype(int)), precision=precision_score(yte, (p >= .5).astype(int)))))(model.predict_proba(Xte)[:, 1])
cm = confusion_matrix(yte, (p_te >= UMBRAL_CLASE).astype(int))
cumple = M['roc_auc'] >= META_AUC and M['recall'] >= META_RECALL

# ------------------------------------------------------------------ gráficos (estilo claro para documento)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
NAVY, TEAL, CORAL, GREY = '#1F3A5F', '#2A9D8F', '#E76F51', '#9AA5B1'

fig, ax = plt.subplots(figsize=(4.6, 3.9))
im = ax.imshow(cm, cmap='Blues')
lab = [['Verdaderos negativos\n(activo bien detectado)', 'Falsos positivos\n(alerta innecesaria)'],
       ['Falsos negativos\n(abandono no detectado)', 'Verdaderos positivos\n(abandono detectado)']]
for i in range(2):
    for j in range(2):
        ax.text(j, i, f'{cm[i, j]}\n', ha='center', va='center', fontsize=17, fontweight='bold', color='white' if cm[i, j] > cm.max() / 2 else NAVY)
        ax.text(j, i + 0.22, lab[i][j], ha='center', va='center', fontsize=7.5, color='white' if cm[i, j] > cm.max() / 2 else NAVY)
ax.set_xticks([0, 1], ['Predicho: activo', 'Predicho: abandono']); ax.set_yticks([0, 1], ['Real: activo', 'Real: abandono'])
ax.set_title(f'Matriz de confusión (prueba, n = {len(yte)}, umbral {UMBRAL_CLASE:.2f})'.replace('.', ','), fontsize=10, color=NAVY)
for s in ax.spines.values(): s.set_visible(False)
fig.tight_layout(); fig.savefig(out / 'G1_matriz_confusion.png', dpi=200); plt.close(fig)

fig, ax = plt.subplots(figsize=(4.6, 3.9))
fpr, tpr, _ = roc_curve(yte, p_te)
fb, tb, _ = roc_curve(yte, baseline.predict_proba(Xte)[:, 1])
ax.plot(fpr, tpr, color=NAVY, lw=2.2, label=f'Modelo optimizado (AUC = {M["roc_auc"]:.3f})'.replace('.', ','))
ax.plot(fb, tb, color=TEAL, lw=1.4, ls='--', label=f'Modelo base (AUC = {MB["roc_auc"]:.3f})'.replace('.', ','))
ax.plot([0, 1], [0, 1], color=GREY, lw=1, ls=':', label='Azar (AUC = 0,5)')
ax.set_xlabel('Tasa de falsos positivos'); ax.set_ylabel('Tasa de verdaderos positivos (recall)')
ax.set_title('Curva ROC en datos de prueba', fontsize=10, color=NAVY); ax.legend(loc='lower right', fontsize=8, frameon=False)
fig.tight_layout(); fig.savefig(out / 'G2_curva_roc.png', dpi=200); plt.close(fig)

fig, ax = plt.subplots(figsize=(6.2, 3.0))
names = ['ROC-AUC', 'Recall', 'Precisión', 'F1', 'Exactitud']; vals = [M['roc_auc'], M['recall'], M['precision'], M['f1'], M['accuracy']]
bars = ax.bar(names, vals, color=[NAVY, NAVY, GREY, GREY, GREY], width=0.6)
ax.axhline(META_AUC, xmin=0.02, xmax=0.2, color=CORAL, lw=2); ax.axhline(META_RECALL, xmin=0.21, xmax=0.39, color=CORAL, lw=2)
ax.text(-0.42, META_AUC + 0.02, 'meta ≥ 0,80', ha='left', color=CORAL, fontsize=8, fontweight='bold'); ax.text(0.58, META_RECALL + 0.02, 'meta ≥ 0,60', ha='left', color=CORAL, fontsize=8, fontweight='bold')
for b, v in zip(bars, vals): ax.text(b.get_x() + b.get_width() / 2, v / 2, f'{v:.3f}'.replace('.', ','), ha='center', color='white', fontsize=9, fontweight='bold')
ax.set_ylim(0, 1.05); ax.set_title('Métricas en prueba frente a la meta del acta', fontsize=10, color=NAVY)
fig.tight_layout(); fig.savefig(out / 'G3_metricas_vs_meta.png', dpi=200); plt.close(fig)

# SHAP
ES = {'recency_dias': 'Días sin visita', 'rfm_score': 'Puntaje RFM', 'distrito': 'Distrito', 'gasto_total': 'Gasto total',
      'pct_compra_productos': '% visitas con compra de productos', 'gasto_productos': 'Gasto en productos', 'frecuencia_mensual': 'Frecuencia mensual',
      'calificacion_promedio': 'Calificación promedio', 'pct_reserva_online': '% reservas en línea', 'ticket_promedio': 'Ticket promedio',
      'ultimo_canal_reserva': 'Último canal de reserva', 'rfm_segmento': 'Segmento RFM', 'total_visitas': 'Total de visitas', 'edad': 'Edad',
      'antiguedad_dias': 'Antigüedad (días)', 'variabilidad_gasto': 'Variabilidad del gasto', 'dias_entre_visitas': 'Días entre visitas',
      'descuento_promedio': 'Descuento promedio', 'pct_visitas_descuento': '% visitas con descuento', 'ultimo_metodo_pago': 'Último método de pago',
      'categoria_favorita': 'Categoría favorita', 'servicios_diferentes': 'Servicios diferentes', 'ratio_gasto_productos': 'Proporción gasto en productos',
      'ratio_visitas_recientes': 'Proporción de visitas recientes', 'visitas_90d': 'Visitas en 90 días', 'sexo': 'Sexo'}
expl = shap.TreeExplainer(model)
sv = expl(Xte)
imp = pd.Series(np.abs(sv.values).mean(0), index=Xte.columns).sort_values(ascending=False)
top = imp.head(12)[::-1]
fig, ax = plt.subplots(figsize=(6.2, 3.8))
ax.barh([ES.get(k, k) for k in top.index], top.values, color=NAVY)
for i, v in enumerate(top.values): ax.text(v, i, f' {v:.3f}'.replace('.', ','), va='center', fontsize=8)
ax.set_xlabel('Impacto medio |SHAP| en la predicción'); ax.set_title('Variables que más influyen en el riesgo de abandono', fontsize=10, color=NAVY)
fig.tight_layout(); fig.savefig(out / 'G4_shap_importancia.png', dpi=200); plt.close(fig)
plt.figure(); Xd = Xte.rename(columns=ES); shap.summary_plot(sv.values, Xd, max_display=10, show=False, plot_size=(6.6, 4.2), color_bar_label='Valor de la variable')
fg = plt.gcf()
for a in fg.axes:
    a.set_xlabel(a.get_xlabel().replace('SHAP value (impact on model output)', 'Valor SHAP (− baja el riesgo · + sube el riesgo)'))
    for t in a.get_yticklabels() + a.texts:
        if t.get_text() == 'High': t.set_text('Alto')
        if t.get_text() == 'Low': t.set_text('Bajo')
cb = fg.axes[-1]; cb.set_yticklabels(['Bajo', 'Alto'])
plt.title('Dirección del efecto de cada variable (SHAP)', fontsize=10, color=NAVY); plt.tight_layout()
plt.savefig(out / 'G5_shap_resumen.png', dpi=200, bbox_inches='tight'); plt.close('all')

# niveles de riesgo en toda la cartera (420)
p_all = model.predict_proba(X)[:, 1]
nivel = np.where(p_all >= UMBRAL_ALTO, 'Alto', np.where(p_all >= UMBRAL_BAJO, 'Medio', 'Bajo'))
dist = pd.Series(nivel).value_counts().reindex(['Bajo', 'Medio', 'Alto']).fillna(0).astype(int)
real_by = pd.crosstab(pd.Series(nivel, name='nivel'), y.rename('churn')).reindex(['Bajo', 'Medio', 'Alto'])
fig, ax = plt.subplots(figsize=(6.2, 2.8))
cols = {'Bajo': TEAL, 'Medio': '#E9C46A', 'Alto': CORAL}
b = ax.bar(dist.index, dist.values, color=[cols[k] for k in dist.index], width=0.55)
for bb, v in zip(b, dist.values): ax.text(bb.get_x() + bb.get_width() / 2, v + 4, f'{v} ({v / len(X) * 100:.1f} %)'.replace('.', ','), ha='center', fontsize=9)
ax.set_ylim(0, dist.max() * 1.22); ax.set_ylabel('Clientes')
ax.set_title(f'Clientes por nivel de riesgo (bajo < 0,30 ≤ medio < 0,60 ≤ alto) · n = {len(X)}', fontsize=10, color=NAVY)
fig.tight_layout(); fig.savefig(out / 'G6_niveles_riesgo.png', dpi=200); plt.close(fig)

# ejemplos individuales y tabla para la dueña (solo prueba: el modelo no vio estos clientes)
te = raw.iloc[idx_te].copy(); te['prob'] = p_te; te['nivel'] = np.where(p_te >= UMBRAL_ALTO, 'Alto', np.where(p_te >= UMBRAL_BAJO, 'Medio', 'Bajo'))
te['pos'] = np.arange(len(te))
pick = pd.concat([te[te.nivel == 'Alto'].sort_values('prob', ascending=False).head(3),
                  te[te.nivel == 'Medio'].sample(min(2, (te.nivel == 'Medio').sum()), random_state=SEED),
                  te[te.nivel == 'Bajo'].sort_values('prob').head(3)])
val = [dict(id=r['ID Cliente'], recency=int(r['Recency']), visitas=int(r['Total Visitas']), gasto=float(r['Gasto Total']),
            prob=float(r['prob']), nivel=r['nivel'], real=r['Churn']) for _, r in pick.iterrows()]


def explain(pos, k=4):
    s = pd.Series(sv.values[pos], index=Xte.columns)
    s = s.reindex(s.abs().sort_values(ascending=False).index).head(k)
    return [(c, float(Xte.iloc[pos][c]) if not isinstance(Xte.iloc[pos][c], str) else Xte.iloc[pos][c], float(v)) for c, v in s.items()]


hi, lo = te.sort_values('prob').iloc[-1], te.sort_values('prob').iloc[0]
ejemplos = [dict(id=r['ID Cliente'], prob=float(r['prob']), nivel=r['nivel'], real=r['Churn'], factores=[(c, str(v), round(s, 3)) for c, v, s in explain(int(r['pos']))]) for r in (hi, lo)]

# empaquetado y versionado
mfile = out / 'modelo_abandono_v1.0.pkl'
with open(mfile, 'wb') as fh: pickle.dump(model, fh)
model.save_model(out / 'modelo_abandono_v1.0.json')
sha = hashlib.sha256(mfile.read_bytes()).hexdigest()
meta = dict(version='1.0', fecha='2026-11-06', edt='EDT-1.3.05', hito='H2 · Modelo predictivo validado',
            algoritmo=f'XGBoost {xgboost.__version__} (XGBClassifier, binary:logistic)', scikit_learn=sklearn.__version__,
            optimizacion='RandomizedSearchCV, 60 iteraciones, StratifiedKFold 5, scoring ROC-AUC',
            mejores_hiperparametros={k: (float(v) if isinstance(v, (np.floating, float)) else v) for k, v in rs.best_params_.items()},
            auc_validacion_cruzada=round(float(rs.best_score_), 4), semilla=SEED,
            dataset=dict(archivo=src.name, clientes=int(len(raw)), abandono=int(y.sum()), tasa_abandono=round(float(y.mean()), 4),
                         entrenamiento=int(len(idx_tr)), prueba=int(len(idx_te)), particion='80/20 estratificada'),
            variables_entrada=list(X.columns), variables_categoricas=list(CAT.values()),
            parametros_variables_derivadas=dict(p25_frecuencia_mensual=REF['p25_frec'], terciles_gasto=REF['ter']),
            umbrales=dict(clasificacion=UMBRAL_CLASE, metodo_umbral='Umbral de riesgo medio configurado en el CRM (config.py), confirmado con predicciones fuera de pliegue del entrenamiento', auc_oof=round(float(oof_auc), 4), recall_oof=round(float(oof_recall), 4), precision_oof=round(float(oof_prec), 4), metricas_prueba_umbral_050={k: round(float(v), 4) for k, v in M50.items()}, riesgo_bajo_menor_a=UMBRAL_BAJO, riesgo_alto_desde=UMBRAL_ALTO),
            metricas_prueba={k: round(float(v), 4) for k, v in M.items()},
            metricas_prueba_modelo_base={k: round(float(v), 4) for k, v in MB.items()},
            matriz_confusion=dict(vn=int(cm[0, 0]), fp=int(cm[0, 1]), fn=int(cm[1, 0]), vp=int(cm[1, 1])),
            meta_acta=dict(roc_auc=META_AUC, recall=META_RECALL), cumple_meta=bool(cumple),
            archivo_modelo=mfile.name, sha256=sha)
json.dump(meta, open(out / 'modelo_abandono_v1.0_metadata.json', 'w'), ensure_ascii=False, indent=2)
with open(out / 'referencias_variables.pkl', 'wb') as fh: pickle.dump(REF, fh)

res = dict(meta=meta, imp=[(k, round(float(v), 4)) for k, v in imp.head(10).items()], dist=dist.to_dict(),
           real_by={k: dict(activos=int(r.get(0, 0)), abandono=int(r.get(1, 0))) for k, r in real_by.fillna(0).iterrows()},
           val=val, ejemplos=ejemplos, n_test_churn=int(yte.sum()))
json.dump(res, open(out / 'resultados.json', 'w'), ensure_ascii=False, indent=2, default=str)
print(json.dumps(dict(M=M, MB=MB, cm=cm.tolist(), cumple=cumple, cv=rs.best_score_, best=rs.best_params_, dist=dist.to_dict(),
                      imp=res['imp'][:8]), indent=1, default=str))
